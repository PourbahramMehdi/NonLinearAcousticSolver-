/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | foam-extend: Open Source CFD
   \\    /   O peration     | Version:     4.0
    \\  /    A nd           | Web:         http://www.foam-extend.org
     \\/     M anipulation  | For copyright notice see file Copyright
-------------------------------------------------------------------------------
License
    This file is part of foam-extend.

    foam-extend is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or (at your
    option) any later version.

    foam-extend is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with foam-extend.  If not, see <http://www.gnu.org/licenses/>.

Application
    laplacianFoam

Description
    Solves a simple Laplace equation, e.g. for thermal diffusion in a solid.

\*---------------------------------------------------------------------------*/

#include "fvCFD.H"

#include "firstOrderLimiter.H"
#include "BarthJespersenLimiter.H"
#include "VenkatakrishnanLimiter.H"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

int main(int argc, char *argv[])
{

#   include "setRootCase.H"

#   include "createTime.H"
#   include "createMesh.H"

    //simpleControl simple(mesh);

#   include "createFields.H"
#   include "createTimeControls.H"


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

    Info<< "\nCalculating pressure distribution\n" << endl;
    
    // Runge-Kutta coefficient
    scalarList beta(4);
    beta[0] = 0.1100;
    beta[1] = 0.2766;
    beta[2] = 0.5000;
    beta[3] = 1.0000;

    // Switch off solver messages
    lduMatrix::debug = 0;

    while (runTime.run())
    {
	

#       include "readTimeControls.H"
#       include "compressibleCourantNo.H"
#       include "setDeltaT.H"

        runTime++;

        Info<< "\n Time = " << runTime.value() << endl;

        // Low storage Runge-Kutta time integration
        
        
        
          forAll (beta, i)
          {
          // Time integration
           NST= ((bet*2)/(rho0*pow(C,2)))*fvc::Sp(p,ddp)               // NonLinear Source term 
              + ((bet*2)/(rho0*pow(C,2)))*fvc::Sp(dp,dp) ; 
                                                                                   
           solve
            (
                1.0/beta[i]*fvm::ddt(p)
               - fvc::Sp(1,dp)
            );
            
            solve
            (
                1.0/beta[i]*fvm::ddt(dp)
                - fvc::Sp(1,ddp)       //-(pow(C,2))*fvc::laplacian(p)             
            );
            
            solve
            (
            
            b/beta[i]*fvm::ddt(ddp)
            +(pow(C,2))*fvc::laplacian(p) 
            - fvm::Sp(1,ddp)
            + ((bet*2)/(rho0*pow(C,2)))*fvm::Sp(p.oldTime(),ddp)  //
            - fvc::Sp(1,NST.oldTime())                                      // .oldTime()
            + ((bet*2)/(rho0*pow(C,2)))*fvc::Sp(ddp.oldTime(),p)
            + ((bet*4)/(rho0*pow(C,2)))*fvc::Sp(dp.oldTime(),dp)  
                
            );
            
            
        }
        
        
          //  state equation for density (Taylor series distribution approximation )
             
           rho = rho0+psi*p+0.5*pow(psi,2)*bet*(pow(p,2)/rho0)+(((k/(rho0*pow(C,4)))*((1./cv)-(1./cp)))*fvc::ddt(p));                   
           
    //  solve velocity equation 
             fvVectorMatrix UEqn
            (
                rho*fvm::ddt(U)
             // + fvm::div(phi,U)   // neglegted from westervelt equation derivation  
              - fvm::laplacian(mu,U)
            );

            solve(UEqn == -fvc::grad(p));
         
         // velocity from Linear Wave theory 
       //  solve
       //     (
       //         fvm::ddt(U)
       //        == (1./rho)*fvc::grad(p)
        //    );
             
       
           
           //  flux calculation 
          phi=fvc::interpolate(rho*U) & mesh.Sf();
           
           runTime.write();

        Info<< "    ExecutionTime = "
            << runTime.elapsedCpuTime()
            << " s\n" << endl;
    }

    Info<< "End\n" << endl;

    return 0;
}


// ************************************************************************* //







  
    
    
    
    
    
    
    
    
