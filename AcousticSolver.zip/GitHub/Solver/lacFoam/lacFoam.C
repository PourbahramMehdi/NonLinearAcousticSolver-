/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | Copyright (C) 2011 OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

Application
    nlacFoam

Description
*   Linear Acoustic Solver :
    Solves the Linear Acoustic Wave Equation With  a Low Storeg Rung-kutta Method
    * 
Author
* Pourbahram Mehdi 

\*---------------------------------------------------------------------------*/

#include "fvCFD.H"



// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

int main(int argc, char *argv[])
{

#   include "setRootCase.H"

#   include "createTime.H"
#   include "createMesh.H"

    

#   include "createFields.H"



// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

    Info<< "\nCalculating pressure distribution\n" << endl;
    
    // Runge-Kutta coefficient
    scalarList beta(4);
    beta[0] = 0.1100;
    beta[1] = 0.2766;
    beta[2] = 0.5000;
    beta[3] = 1.0000;

    // Switch off solver messages
    lduMatrix::debug = 0;

    while (runTime.run())
    {
	
        runTime++;

        Info<< "\n Time = " << runTime.value() << endl;

        // Low storage Runge-Kutta time integration
        
        
        
          forAll (beta, i)
          {
          // Time integration                                                             
           solve
            (
                1.0/beta[i]*fvm::ddt(P)
               - fvc::Sp(1,dp)
            );
            
            solve
            (
                1.0/beta[i]*fvm::ddt(dp)
                -(pow(C,2))*fvc::laplacian(P)            
            );
            
            
        }
        
        
          //  state equation for density (Taylor series distribution approximation )
             
           rho = rho0+psi*P+(((k/(rho0*pow(C,4)))*((1./cv)-(1./cp)))*fvc::ddt(P));                   
           
    //  solve velocity equation 
             fvVectorMatrix UEqn
            (
                rho*fvm::ddt(U) 
              - fvm::laplacian(mu,U)
            );

            solve(UEqn == -fvc::grad(P));
         
           //  flux calculation 
          phi=fvc::interpolate(rho*U) & mesh.Sf();
           
           runTime.write();

        Info<< "    ExecutionTime = "
            << runTime.elapsedCpuTime()
            << " s\n" << endl;
    }

    Info<< "End\n" << endl;

    return 0;
}


// ************************************************************************* //







  
    
    
    
    
    
    
    
    
