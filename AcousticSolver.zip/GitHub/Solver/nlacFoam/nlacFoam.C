/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | Copyright (C) 2011 OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

Application
    nlacFoam

Description
*   NonLinear Acoustic Solver :
    Solves the Westervelt Nonlinear Acoustic Wave Equation With  a simple predict and Correct Method
    * 
Author
* Pourbahram Mehdi 

\*---------------------------------------------------------------------------*/

#include "fvCFD.H"

#include "simpleControl.H"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

int main(int argc, char *argv[])
{

#   include "setRootCase.H"

#   include "createTime.H"
#   include "createMesh.H"

   simpleControl simple(mesh);

#   include "createFields.H"



// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

    Info<< "\nCalculating pressure distribution\n" << endl;
   
    // Switch off solver messages
    lduMatrix::debug = 0;
    
    		
  while (simple.loop())
    {
    


        Info<< "Time = " << runTime.timeName() << nl << endl;
  
        while (simple.correctNonOrthogonal())   
        {
			                                                           
           solve
            (
                 fvm::ddt(p)       
               - fvc::Sp(1,dp)
            );
            
            solve
            (
                  fvm::ddt(dp)
                 -fvc::Sp(1,ddp)                               
            );
            
            solve
            (
            
            b*fvm::ddt(ddp)
           +fvc::laplacian((pow(C,2)),p) 
           -fvm::Sp(1,ddp)
           +((bet*2)/(rho0*pow(C,2)))*fvm::Sp(p,ddp)                           
           +((bet*2)/(rho0*pow(C,2)))*fvc::Sp(dp,dp)                        
            
            );
         
          }
   
   
   
   
      
      
     //  state equation for density (Taylor series distribution approximation )
             
           rho = rho0+psi*p+(((k/(rho0*pow(C,4)))*((1./cv)-(1./cp)))*fvc::ddt(p));                   
           
    //  solve velocity equation 
             fvVectorMatrix UEqn
            (
                rho*fvm::ddt(U) 
              - (mub+(4./3)*mu)*fvm::laplacian(U)
            );

            solve(UEqn == -fvc::grad(p));
         
           //  flux calculation 
          phi=fvc::interpolate(rho*U) & mesh.Sf();
           
           runTime.write();

        Info<< "    ExecutionTime = "
            << runTime.elapsedCpuTime()
            << " s\n" << endl;
    }
    
    Info<< "End\n" << endl;

    return 0;
}


// ************************************************************************* //







  
    
    
    
    
    
    
    
    
